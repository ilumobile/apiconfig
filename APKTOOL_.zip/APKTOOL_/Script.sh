#!/bin/bash

# Copyright (C) 2015 Călin Neamţu (nilac8991)

# NOTE.
# This script is intended to be written in this way
# Don't try to modify this on your own because it will not work again as it should unless you've got experience with computer programming.
# APKTool was not made by me, so all the credits for it goes to the Original Author!
# Remember this script will only work on Ubuntu or Ubuntu based distros

function dependencies()
{
  sleep 5
  if sudo apt-get install oracle-java7-installer;then
      echo -e "Java seems to be installed!"
  else
  {
    sudo add-apt-repository ppa:webupd8team/java
    sudo apt-get update
    sleep 2
    clear
    sudo apt-get install oracle-java7-installer;
  }
  fi
  if sudo apt-get install openjdk-7-jre && sudo apt-get install openjdk-7-jdk;then
    echo -e "OpenJDK 7 seems to be installed!"
  else
  {
    sudo apt-get install openjdk-7-jre
    sudo apt-get install openjdk-7-jdk
  }
  fi
  tput setaf 2
  echo -e "All Dependencies are fully installed to the system"
  tput sgr0
}

function removeapktool()
{
  echo -e "Are you sure you want do uninstall?"
  echo -e "Please insert 0 for no and 1 for yes"
  read choice
  if [[ $choice == "1" ]];then
    {
      sleep 5
      sudo add-apt-repository --remove ppa:webupd8team/java -y
      sudo apt-get remove oracle-java7-installer
      sudo apt-get remove  openjdk-7-jre
      sudo apt-get remove openjdk-7-jdk
      clear
      tput setaf 2
      echo -e "Dependencies fully removed from the system"
      sleep 3
      cd /usr/bin
      sudo rm -f apktool
      sudo rm -f apktool.jar
      sudo rm -rf signapk.jar
      sudo rm -rf testkey.pk8
      sudo rm -rf testkey.x509.pem
      sleep 2
      echo -e "Apktool fully removed from the system"
      tput sgr0
      exit
    }
  else
    Welcome
  fi

}

function installation()
{
  echo -e "Welcome! just relax, it will take just a minute"
  echo -e "Installing some dependencies..."
  sleep 3
  dependencies
  clear
  echo -e "Installing APKTool...."
  sleep 4
  cd SigningTool
  tput setaf 1
  if sudo chown -R $USER:$USER signapk.jar; then
    if sudo chown -R $USER:$USER testkey.pk8; then
      if sudo chown -R $USER:$USER testkey.x509.pem; then
        echo -e " "
      else 
         echo -e "Opps somthing, went wrong, please check your files"
         exit 1
      fi
    else 
       echo -e "Opps somthing, went wrong, please check your files"
       exit 1
    fi
  else 
     echo -e "Opps somthing, went wrong, please check your files"
     exit 1
  fi
  sudo chmod +x signapk.jar
  sudo chmod +x testkey.pk8
  sudo chmod +x testkey.x509.pem
  cd ..
  if sudo chown -R $USER:$USER apktool; then
    if sudo chown -R $USER:$USER apktool.jar; then
      if sudo chmod +x apktool; then
        if sudo chmod +x apktool.jar; then
          echo -e " "
        else 
          echo -e "Opps somthing, went wrong, please check your files"
        fi
      else
        echo -e "Opps somthing, went wrong, please check your files"
      fi
    else 
      echo -e "Opps somthing, went wrong, please check your files"
    fi
  else 
    echo -e "Opps somthing, went wrong, please check your files"
  fi
  tput sgr0
  sudo mv apktool /usr/bin
  sudo mv apktool.jar /usr/bin
  cd SigningTool
  sudo mv signapk.jar /usr/bin
  sudo mv testkey.pk8 /usr/bin
  sudo mv testkey.x509.pem /usr/bin
  tput setaf 2
  echo -e "Congratulations APKTool was successfully installed!"
  sleep 4
  tput sgr0
  exit
}

function apktoolupgrade()
{
  clear
  echo -e "Upgrading apktool..."
  sleep 4
  tput setaf 6
  echo -e "Make sure you have apktool.jar in the same directory where the script is located"
  echo -e "Press enter when you're ready"
  read enter
  tput setaf 1
    if sudo chown -R $USER:$USER apktool.jar; then
      echo -e " "
    else 
      echo -e "Opps somthing, went wrong, please check your files, remember the name of the upgraded apktool must be: 'apktool.jar' "
      exit 1
    fi
  tput sgr0
  sudo chmod +x apktool.jar;
  sudo mv apktool.jar apktool_new.jar
  sudo mv apktool_new.jar /usr/bin
  cd /usr/bin
  sudo rm -f apktool.jar
  sudo mv apktool_new.jar apktool.jar
  tput setaf 2
  echo -e "APKTool is now upgrated!"
  tput sgr0
  sleep 3
  exit
}


function Welcome()
{
  if hash apktool 2>/dev/null; then
    clear
    echo -e "Welcome!"
    echo -e "Please make your choice"
    tput setaf 2
    echo -e "Apktool is installed!"
    tput sgr0
    echo -e "1) Upgrade APKTool"
    echo -e "2) Check dependencies"
    echo -e "3) Remove apktool"
  else
    echo -e "Welcome!"
    echo -e "Please make your choice"
    tput setaf 1
    echo -e "Apktool is not installed!"
    tput sgr0
    echo -e "4) Install APKTool"
fi
  echo -e "5) Exit"
  read choice

case $choice in
  1) apktoolupgrade ;;
  2) dependencies ;;
  3) removeapktool ;;
  4) installation ;;
  5) exit ;;
  *) clear && echo -e "Invalid option, please choice a new one!" ;;
esac
}

while [[ true ]]; do
Welcome
done
